#ifndef ADC_H
#define ADC_H

#include <avr/io.h>

// ADC initialization function
void Adc_Init() {
    // Set the reference voltage to Vcc (5V)
    // Left adjust the result for 8-bit precision
    ADMUX = (1 << REFS0);  // Vcc reference, ADMUX is for selecting the reference voltage.
    ADCSRA = (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // Set ADC prescaler to 128 (optimal for 16 MHz clock)
    ADCSRA |= (1 << ADEN); // Enable ADC
}

// Function to read ADC value from a given channel (0-7)
unsigned short Adc_ReadChannel(unsigned char channel) {
    // Set the ADC channel (0-7)
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F); // Mask lower 4 bits for channel selection
    ADCSRA |= (1 << ADSC);  // Start conversion

    // Wait for conversion to complete
    while (ADCSRA & (1 << ADSC)) {
        // Wait until ADSC becomes 0 (conversion finished)
    }

    return ADC;  // Return the result from ADC data register
}

#endif